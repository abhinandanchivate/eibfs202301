class Employee {
  // class : its a predefined keyword used to define/declare the class
  // Employee : Name of the class
  // parameterized constructor
  // it is used to initialize the fields on the basis of passed values to constructor.
  constructor(eId, eName, eSalary) {
    this.empId = eId;
    this.empName = eName;
    this.empSalary = eSalary;

    console.log("hello from constructor");
  }
}
// DC initialization of fields
// this keyword is used to refer the current object.

let employee = new Employee(100, "abhi", 200);
// let : to declare the variable
// employee : name of the variable
// new : new its a keyword used to define/declare the object
// Employee() :
console.log(employee);

// Account : // accountType, accountHolderName, balance, address, contactNumber.

class CRUDEmployee {
  employees = [];
  // employees : will hold an array of employee
  addEmployee = (employee) => {
    let res = this.employees.push(employee);
    try {
      if (res == 1) {
        return "success";
      }
    } catch (err) {
      console.log("error occured", err);
      return "error";
    }
  };
  updateEmployee = (eid, employee) => {};
  deleteEmployeeById = (eid) => {};
}

let crudEmployee = new CRUDEmployee();
// we created the object of our crud class

let result = crudEmployee.addEmployee(new Employee(1, "abhi", 100));
console.log(result);
if (result == "success") {
  console.log("employee added successfully");
} else {
  console.log("employee is not added");
}

// try block it will hold the code which may raise / create the problem.

// catch block : will give the solution to our
//raised problem inside the try block
// exception handler
