class EmployeeService {
  employees = [];
  // employees : will hold an array of employee
  addEmployee = (employee) => {
    let res = this.employees.push(employee);
    try {
      if (res == 1) {
        return "success";
      }
    } catch (err) {
      console.log("error occured", err);
      return "error";
    }
  };
  updateEmployee = (eid, employee) => {};
  deleteEmployeeById = (eid) => {};
}
