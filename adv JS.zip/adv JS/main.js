// main

let employeeService = new EmployeeService();
// we created the object of our crud class

let result = employeeService.addEmployee(new Employee(1, "abhi", 100));
console.log(result);
if (result == "success") {
  console.log("employee added successfully");
} else {
  console.log("employee is not added");
}
